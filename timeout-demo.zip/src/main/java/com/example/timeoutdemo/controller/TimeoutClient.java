package com.example.timeoutdemo.controller;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

@Component
public class TimeoutClient implements CommandLineRunner {

    @Override
    public void run(String... args) throws Exception {
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
        factory.setConnectTimeout(10000); // 10 seconds
        factory.setReadTimeout(5 * 60 * 1000); // 5 minutes

        RestTemplate restTemplate = new RestTemplate(factory);
        try {
            System.out.println("Sending POST request to /api/slow...");
            restTemplate.postForObject("http://localhost:8080/api/slow", "{}", String.class);
        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
        }
    }
}
