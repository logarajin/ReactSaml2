package com.example.timeoutdemo.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class SlowController {

    @PostMapping("/slow")
    public String slowEndpoint(@RequestBody(required = false) String body) throws InterruptedException {
        System.out.println("Received POST request. Simulating long processing...");
        Thread.sleep(6 * 60 * 1000); // 6 minutes
        return "Completed after 6 minutes!";
    }
}
