package com.example.timeoutdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeoutDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(TimeoutDemoApplication.class, args);
    }
}
