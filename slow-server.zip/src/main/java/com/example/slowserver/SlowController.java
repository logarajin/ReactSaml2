package com.example.slowserver;

import org.springframework.web.bind.annotation.*;

@RestController
public class SlowController {

    @PostMapping("/slow-response")
    public String slowResponse(@RequestBody(required = false) String body) {
        System.out.println("Received request: " + body);
        try {
            // Simulate long processing (10 minutes)
            Thread.sleep(10 * 60 * 1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return "Response after 10 minutes!";
    }
}
